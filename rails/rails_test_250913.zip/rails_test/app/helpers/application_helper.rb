module ApplicationHelper
  # The splat (*) operator concatenates all arguments passed to the method into an array.
  def title(*parts)
    unless parts.empty?

      content_for :title do
        (parts << "RailsTest").join(" - ") unless parts.empty?
      end

      # Or we could have done this:
      #"#{parts[0]} - #{parts[1]} - RailsTest"
    end
  end
end
