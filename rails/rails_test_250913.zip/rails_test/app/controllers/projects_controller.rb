class ProjectsController < ApplicationController

  # GET /projects/new
  def new
     @project = Project.new
  end

  # POST to /projects -> which then redirects to GET /projects/:id if successful
  def create
    # The parameter is a HashWithIndifferentAccess, which can access parameters via symbols
    # To inspect: puts params.inspect
    # As of rails 3, contents at this point should be:
    #   "commit"
    #   "action"
    #   "project" -> a HashWithIndifferentAccess containing the fields from the form, eg params[:project][:name]
    #   "controller"
    @project = Project.new(params[:project])
    if @project.save

      # This is a way of passing messages to the next request.
      # The messages are stored in the session and removed at the completion of the next request.
      flash[:notice] = "Project has been created."

      # This will redirect based on the object: in this case to project_path(@project).  This goes to the show action.
      #
      # You can combine with the flash:
      #   redirect_to @project
      #   :notice => "Project has been created"
      #
      redirect_to @project
    else
      flash[:alert] = "Project has not been created."
      render :action => "new"
    end
  end

  # Called when we display the index page.
  def index
    @projects = Project.all
  end

  # GET of /projects/:id
  def show
    @project = Project.find(params[:id])
  end

  def edit
    @project = Project.find(params[:id])
  end
  def update
    @project = Project.find(params[:id])
    if @project.update_attributes(params[:project])
      flash[:notice] = "Project has been updated."
      redirect_to @project
    else
      flash[:alert] = "Project has not been updated."
      render :action => "edit"
    end
  end

  def destroy
    @project = Project.find(params[:id])
    @project.destroy
    flash[:notice] = "Project has been deleted."
    redirect_to projects_path
  end
end
