#
# Note: there's a possible race condition when validating uniqueness, if 2 connections make the validation at the same time
#
class Project < ActiveRecord::Base
  attr_accessible :name
  validates :name, :presence => true
end
