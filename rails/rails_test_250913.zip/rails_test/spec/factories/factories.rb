FactoryGirl.define do

  factory :project do
    name 'RailsTest'
  end
end

