Given /^there is a project called "([^\"]*)"$/ do |name|
  project = FactoryGirl.create(:project, :name => name)

  # We also could have done this:
  #Project.create(:name => "TextMate 2")
end